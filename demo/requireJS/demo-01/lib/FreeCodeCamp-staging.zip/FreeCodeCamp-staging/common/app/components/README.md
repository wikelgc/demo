things like NavBar and Footer go here
